// conexión y ejecución de consultas en MySQL
const mysql = require('mysql2');

// Creamos una conexión a la base de datos MySQL
const connection = mysql.createConnection({
    host: 'localhost',     
    user: 'root',
    password: '',          
    database: 'testdb'     
});

//conexión con la base de datos
connection.connect(err => {
    if (err) {  
        console.error('Error de conexión:', err); 
        return; 
    }
    console.log('Conectado a MySQL'); 

    // Ejecutamos una consulta SQL para obtener todos los registros de la tabla "users"
    connection.query('SELECT * FROM users', (err, results) => {
        if (err) throw err; 

        console.log('Usuarios:', results); 

        connection.end(); 
    });
});
