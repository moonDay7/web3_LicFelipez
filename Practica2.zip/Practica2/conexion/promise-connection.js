const mysql = require('mysql2/promise');

//  Definimos una función asíncrona principal
async function main() {
    try {
        //  Crear una conexión a la base de datos usando Promesas (async/await)
        const connection = await mysql.createConnection({
            host: 'localhost',  
            user: 'root',       
            password: '',       
            database: 'testdb'  
        });

        console.log('Conectado a MySQL');        
        const [rows] = await connection.execute('SELECT * FROM users');
        console.log('Usuarios:', rows); 

        await connection.end();
    } catch (err) {
        console.error('Error:', err);
    }
}

main();
