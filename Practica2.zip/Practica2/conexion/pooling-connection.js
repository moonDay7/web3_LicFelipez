const mysql = require('mysql2');

// Crear un pool de conexiones
const pool = mysql.createPool({
    host: 'localhost',        
    user: 'root',             
    password: '',             
    database: 'testdb',       
    waitForConnections: true, 
    connectionLimit: 10,      
    queueLimit: 0             
});


pool.query('SELECT * FROM users', (err, results) => {
    if (err) throw err;  
    console.log('Usuarios:', results); 
});
