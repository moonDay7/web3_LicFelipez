const mysql = require('mysql2');  

//para medir tiempos de ejecución  
const { performance } = require('perf_hooks');  

// Función para medir el tiempo de ejecución de cada método de conexión
async function testConnection(method, func) {
    const start = performance.now(); // Captura el tiempo de inicio
    await func(); // Ejecuta la función de conexión
    const end = performance.now(); // Captura el tiempo después de la ejecución
    console.log(`${method} tomó ${end - start} ms`); // Muestra el tiempo total transcurrido
}

//  Conexión Básica (método tradicional con callbacks)
async function basicConnection() {
    // Creamos una conexión directa a MySQL
    const connection = mysql.createConnection({
        host: 'localhost',  
        user: 'root',       
        password: '',       
        database: 'testdb'  
    });

    
    connection.connect(err => {
        if (err) throw err; 

        // Ejecutamos una consulta SQL
        connection.query('SELECT * FROM users', (err, results) => {
            if (err) throw err;

            connection.end(); 
        });
    });
}

// Conexión con Promesas (usando async/await para mayor legibilidad)
async function promiseConnection() {
    // Establecemos conexión a MySQL utilizando el módulo de Promesas
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'testdb'
    });

    // Ejecutamos una consulta SQL usando await (permite evitar callbacks)
    await connection.execute('SELECT * FROM users');

    // Cerramos la conexión después de ejecutar la consulta
    await connection.end();
}

//  Conexión con Pooling (gestiona múltiples conexiones para optimización)
async function poolingConnection() {
    // Creamos un pool de conexiones en lugar de una conexión directa
    const pool = mysql.createPool({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'testdb',
        waitForConnections: true,  // Espera conexiones en lugar de fallar si está lleno
        connectionLimit: 10,       // Número máximo de conexiones simultáneas
        queueLimit: 0              // No hay límite de consultas en la cola
    });

    // Ejecutamos una consulta SQL en el pool
    pool.query('SELECT * FROM users', (err, results) => {
        if (err) throw err; 
    });
}

// Ejecutar todas las pruebas y medir los tiempos de ejecución
(async () => {
    await testConnection('Conexión Básica', basicConnection);         
    await testConnection('Conexión con Promesas', promiseConnection); 
    await testConnection('Conexión con Pooling', poolingConnection);  
})();
