//


const mysql = require('mysql2'); // Importa el módulo mysql2 para la conexión con MySQL

// Configura la conexión a la base de datos MySQL
const conexion = mysql.createConnection({
    host: 'localhost',  
    user: 'root',  
    password: '',  
    database: 'crud_bd'  
});

// Intenta establecer la conexión con la base de datos
conexion.connect((error) => {
    if (error) {
        console.error('Error al conectar a la base de datos:', error);  
        return;
    }
    console.log('Conexión exitosa a la base de datos');  
});

module.exports = conexion;  
