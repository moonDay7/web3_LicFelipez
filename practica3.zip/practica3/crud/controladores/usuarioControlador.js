const Usuario = require('../modelos/Usuario'); // Importa el modelo Usuario para interactuar con la base de datos

// Controlador para listar todos los usuarios
exports.listarUsuarios = (req, res) => {
    Usuario.obtenerTodos((error, resultados) => {
        if (error) throw error; 
        res.render('index', { usuarios: resultados }); 
    });
};

// Controlador para mostrar el formulario de creación de usuario
exports.mostrarFormularioCrear = (req, res) => {
    res.render('crear'); 
};

// Controlador para crear un nuevo usuario
exports.crearUsuario = (req, res) => {
    const { nombre, correo, edad } = req.body; 

    Usuario.crear({ nombre, correo, edad }, (error) => {
        if (error) throw error; 
        res.redirect('/'); 
    });
};

// Controlador para mostrar el formulario de edición con los datos del usuario
exports.mostrarFormularioEditar = (req, res) => {
    Usuario.obtenerPorId(req.params.id, (error, resultados) => {
        if (error) throw error; 
        res.render('editar', { usuario: resultados[0] }); 
    });
};

// Controlador para actualizar un usuario existente
exports.actualizarUsuario = (req, res) => {
    const { nombre, correo, edad } = req.body; 

    Usuario.actualizar(req.params.id, { nombre, correo, edad }, (error) => {
        if (error) throw error; 
        res.redirect('/'); 
    });
};

// Controlador para eliminar un usuario
exports.eliminarUsuario = (req, res) => {
    Usuario.eliminar(req.params.id, (error) => {
        if (error) throw error; 
        res.redirect('/'); 
    });
};
