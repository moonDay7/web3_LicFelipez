const express = require('express'); // Importa Express
const router = express.Router(); // Crea un enrutador de Express
const usuarioControlador = require('../controladores/usuarioControlador'); // Importa el controlador de usuarios

// Ruta para listar usuarios
router.get('/', usuarioControlador.listarUsuarios);

router.get('/crear', usuarioControlador.mostrarFormularioCrear);

router.post('/crear', usuarioControlador.crearUsuario);

router.get('/editar/:id', usuarioControlador.mostrarFormularioEditar);

router.post('/editar/:id', usuarioControlador.actualizarUsuario);

//(usando POST en lugar de GET para mayor seguridad)
router.post('/eliminar/:id', usuarioControlador.eliminarUsuario);

module.exports = router; 
