const express = require('express'); 
const path = require('path'); // Importa el módulo path para trabajar con rutas de archivos
const methodOverride = require('method-override'); // Permite el uso de métodos HTTP como PUT y DELETE en formularios HTML

const app = express(); 

// Configuración de la carpeta de vistas y motor de plantillas (EJS)
app.set('views', path.join(__dirname, 'vistas')); 
app.set('view engine', 'ejs'); //ejs

// Middleware
app.use(express.urlencoded({ extended: true })); //procesa los datos del formulario
app.use(methodOverride('_method')); 
app.use(express.static(path.join(__dirname, 'public'))); //servir archivos estáticos (CSS, JS, imágenes)

// Rutas
const usuarioRutas = require('./rutas/usuarioRutas');
app.use('/', usuarioRutas); 

// Inicia el servidor en el puerto 3000
app.listen(3000, () => {
    console.log('Servidor ejecutándose en http://localhost:3000'); 
});
