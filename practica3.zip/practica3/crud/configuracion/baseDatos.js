const mysql = require('mysql2'); // Importa el módulo mysql2 para la conexión con MySQL
const dotenv = require('dotenv'); // Importa dotenv para manejar variables de entorno

dotenv.config(); // Carga las variables de entorno desde el archivo .env

const conexion = mysql.createConnection({
    host: process.env.DB_HOST,     // Host de la base de datos (localhost)
    user: process.env.DB_USER,    
    password: process.env.DB_PASSWORD, 
    database: process.env.DB_NAME  
});

conexion.connect((error) => { 
    if (error) { 
        console.error('Error conectando a la base de datos:', error); 
        return;
    }
    console.log('Conectado a la base de datos.'); 
});

module.exports = conexion; 
