const conexion = require('../db'); // Importa la conexión a la base de datos

class Usuario {
    // Método para obtener todos los usuarios de la base de datos
    static obtenerTodos(callback) {
        conexion.query('SELECT * FROM usuarios', callback);
    }

    // Método para obtener un usuario por su ID
    static obtenerPorId(id, callback) {
        conexion.query('SELECT * FROM usuarios WHERE id = ?', [id], callback);
    }

    // Método para crear un nuevo usuario
    static crear(datos, callback) {
        conexion.query('INSERT INTO usuarios SET ?', datos, callback);
    }

    // Método para actualizar los datos de un usuario por su ID
    static actualizar(id, datos, callback) {
        conexion.query('UPDATE usuarios SET ? WHERE id = ?', [datos, id], callback);
    }

    // Método para eliminar un usuario por su ID
    static eliminar(id, callback) {
        conexion.query('DELETE FROM usuarios WHERE id = ?', [id], callback);
    }
}

module.exports = Usuario; // Exporta la clase para su uso en otros archivos
