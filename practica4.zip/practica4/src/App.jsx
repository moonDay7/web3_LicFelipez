import { useEffect, useState } from 'react'
import axios from 'axios'

function App() {
  const [registros, setRegistros] = useState([])
  const [form, setForm] = useState({ nombre: '', correo: '' })
  const [editId, setEditId] = useState(null)

  // URL base de tu backend (ajusta si tu backend usa otro puerto)
  const baseURL = 'http://localhost:3001/api/registros'

  // Obtener registros
  const fetchRegistros = async () => {
    try {
      const res = await axios.get(baseURL)
      setRegistros(res.data)
    } catch (error) {
      console.error('Error al obtener registros:', error)
    }
  }

  useEffect(() => {
    fetchRegistros()
  }, [])

  // Actualizar estado del formulario
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  // Crear o actualizar registro
  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      if (editId === null) {
        await axios.post(baseURL, form)
      } else {
        await axios.put(`${baseURL}/${editId}`, form)
      }
      setForm({ nombre: '', correo: '' })
      setEditId(null)
      fetchRegistros()
    } catch (error) {
      console.error('Error al guardar registro:', error)
    }
  }

  // Preparar formulario para editar
  const handleEdit = (registro) => {
    setForm({ nombre: registro.nombre, correo: registro.correo })
    setEditId(registro.id)
  }

  // Eliminar registro
  const handleDelete = async (id) => {
    if (window.confirm('¿Quieres eliminar este registro?')) {
      try {
        await axios.delete(`${baseURL}/${id}`)
        fetchRegistros()
      } catch (error) {
        console.error('Error al eliminar registro:', error)
      }
    }
  }

  // Cancelar edición
  const handleCancel = () => {
    setForm({ nombre: '', correo: '' })
    setEditId(null)
  }

  return (
    <div className="container mt-5">
      <h1>CRUD Básico - Registros</h1>
      <form onSubmit={handleSubmit} className="mb-4">
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">Nombre</label>
          <input
            id="nombre"
            type="text"
            name="nombre"
            value={form.nombre}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="correo" className="form-label">Correo</label>
          <input
            id="correo"
            type="email"
            name="correo"
            value={form.correo}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">
          {editId === null ? 'Crear' : 'Actualizar'}
        </button>
        {editId !== null && (
          <button type="button" className="btn btn-secondary ms-2" onClick={handleCancel}>
            Cancelar
          </button>
        )}
      </form>

      <table className="table table-bordered">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {registros.length > 0 ? (
            registros.map((r) => (
              <tr key={r.id}>
                <td>{r.id}</td>
                <td>{r.nombre}</td>
                <td>{r.correo}</td>
                <td>
                  <button className="btn btn-warning btn-sm me-2" onClick={() => handleEdit(r)}>Editar</button>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(r.id)}>Eliminar</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center">No hay registros</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}

export default App
