const express = require('express');
const cors = require('cors');
const app = express();

const registroRoutes = require('./routes/registroRoutes');

app.use(cors());
app.use(express.json());

app.use('/api/registros', registroRoutes);

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`🚀 Servidor backend corriendo en http://localhost:${PORT}`);
});
