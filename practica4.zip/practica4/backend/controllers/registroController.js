const Registro = require('../models/registroModel');

exports.getAll = (req, res) => {
  Registro.getAll((err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
};

exports.getById = (req, res) => {
  Registro.getById(req.params.id, (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result[0]);
  });
};

exports.create = (req, res) => {
  Registro.create(req.body, (err, result) => {
    if (err) return res.status(500).send(err);
    res.json({ id: result.insertId, ...req.body });
  });
};

exports.update = (req, res) => {
  Registro.update(req.params.id, req.body, (err) => {
    if (err) return res.status(500).send(err);
    res.json({ id: req.params.id, ...req.body });
  });
};

exports.delete = (req, res) => {
  Registro.delete(req.params.id, (err) => {
    if (err) return res.status(500).send(err);
    res.json({ msg: 'Registro eliminado' });
  });
};
