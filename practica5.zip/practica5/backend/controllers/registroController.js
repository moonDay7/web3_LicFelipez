// backend/controllers/registroController.js
const Registro = require('../models/registroModel');

exports.getAll = (req, res) => {
  Registro.getAll((err, results) => {
    if (err) res.status(500).send(err);
    else res.json(results);
  });
};

exports.create = (req, res) => {
  Registro.create(req.body, (err, result) => {
    if (err) res.status(500).send(err);
    else res.json({ message: 'Registro creado' });
  });
};

exports.update = (req, res) => {
  const id = req.params.id;
  Registro.update(id, req.body, (err, result) => {
    if (err) res.status(500).send(err);
    else res.json({ message: 'Registro actualizado' });
  });
};

exports.delete = (req, res) => {
  const id = req.params.id;
  Registro.delete(id, (err, result) => {
    if (err) res.status(500).send(err);
    else res.json({ message: 'Registro eliminado' });
  });
};
