// backend/db.js
const mysql = require('mysql2');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // pon tu contraseña si tienes
  database: 'practica5'
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Base de datos conectada');
});

module.exports = connection;
