// backend/app.js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const registroRoutes = require('./routes/registroRoutes');
app.use('/api/registros', registroRoutes);

app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});
