<template>
  <div class="container mt-4">
    <h1 class="text-center">CRUD con Vue + Node</h1>
    <form @submit.prevent="guardar">
      <div class="mb-3">
        <input v-model="form.nombre" type="text" class="form-control" placeholder="Nombre" required />
      </div>
      <div class="mb-3">
        <input v-model="form.correo" type="email" class="form-control" placeholder="Correo" required />
      </div>
      <button class="btn btn-success" type="submit">
        {{ editarId ? 'Actualizar' : 'Crear' }}
      </button>
    </form>

    <table class="table mt-4 table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Correo</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in registros" :key="item.id">
          <td>{{ item.id }}</td>
          <td>{{ item.nombre }}</td>
          <td>{{ item.correo }}</td>
          <td>
            <button class="btn btn-warning btn-sm" @click="editar(item)">Editar</button>
            <button class="btn btn-danger btn-sm" @click="eliminar(item.id)">Eliminar</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      registros: [],
      form: {
        nombre: '',
        correo: ''
      },
      editarId: null
    };
  },
  methods: {
    cargarDatos() {
      axios.get('http://localhost:3000/api/registros').then(res => {
        this.registros = res.data;
      });
    },
    guardar() {
      if (this.editarId) {
        axios.put(`http://localhost:3000/api/registros/${this.editarId}`, this.form).then(() => {
          this.form = { nombre: '', correo: '' };
          this.editarId = null;
          this.cargarDatos();
        });
      } else {
        axios.post('http://localhost:3000/api/registros', this.form).then(() => {
          this.form = { nombre: '', correo: '' };
          this.cargarDatos();
        });
      }
    },
    editar(item) {
      this.form.nombre = item.nombre;
      this.form.correo = item.correo;
      this.editarId = item.id;
    },
    eliminar(id) {
      if (confirm('¿Deseas eliminar este registro?')) {
        axios.delete(`http://localhost:3000/api/registros/${id}`).then(() => {
          this.cargarDatos();
        });
      }
    }
  },
  mounted() {
    this.cargarDatos();
  }
};
</script>
